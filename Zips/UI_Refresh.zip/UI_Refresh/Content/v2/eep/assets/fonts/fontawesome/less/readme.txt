Remove 'int-icon-download-alt' from doc site

Remove 'int-icon-renminbi' as this icon no longer exists in 4.0.3

Update use of 'int-icon-reorder' within framework to 'int-icon-bars'.